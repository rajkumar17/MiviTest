//
//  JSonParser.swift
//  MiviTest
//
//  Created by Sogo Computers on 5/5/18.
//  Copyright © 2018 Sogo Computers. All rights reserved.
//

import UIKit

// MARK:  Model

struct JsonKeys {
    let includedKey:String = "included"
    let dataKey:String = "data"
    let attributeKey:String = "attributes"
    let keySubscritpTypes: String = "subscriptions"
    let keyServicesTypes: String = "services"
    let keyProductsTypes: String = "products"
    let keyAccoutnsTypes: String = "accounts"
}
// MARK: Class
class JSonParser {

    
   class func parseJSONFile()
    {
        if let path = Bundle.main.path(forResource: "collection", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String: AnyObject]
                let keys = JsonKeys()
                if let jsonResult = jsonResult as NSDictionary?{
                    for (key,value) in jsonResult{
                        if ((key)as? String == keys.includedKey)
                        {
                            for getInclude in value as! NSArray{
                                let getType = (getInclude as? [String: AnyObject])?["type"]
                                for includeDetails in getInclude as! NSDictionary{
                                    
                                    if ((includeDetails.key)as! String == keys.attributeKey){
                                        if (getType) as!String  == keys.keySubscritpTypes{

                                            if let details = includeDetails.value as? NSDictionary {
                                                UserDefaults.standard.set((details["included-data-balance"] as? Int), forKey: "included-data-balance") //Bool
                                                
                                            }
                                        }else if (getType) as!String == keys.keyProductsTypes{
                                            
                                            if let details = includeDetails.value as? NSDictionary {
                                                UserDefaults.standard.set((details["name"] as? String), forKey: "name")
                                                UserDefaults.standard.set((details["price"] as? Int), forKey: "price")
                                            }
                                           
                                        }else if (getType) as!String == keys.keyServicesTypes{
                                            if let details = includeDetails.value as? NSDictionary {
                                                UserDefaults.standard.set((details["msn"] as? String), forKey: "msn")
                                                

                                            }
                                        }
                                    }
                                }
                            }
                           
                        }else if ((key)as? String == keys.dataKey){
                            
                            for dataDetails in value as! NSDictionary{
                                if ((dataDetails.key)as? String == keys.attributeKey){
                                    
                                    if let details = dataDetails.value as? [String:Any] {
                                        let name = details["first-name"] as! String
                                        let lastname = details["last-name"] as! String
                                        let names =   "\(name) \(lastname)"                                         
                                        UserDefaults.standard.set(names, forKey: "name")
                                        UserDefaults.standard.set((details["title"] as? String), forKey: "title")
                                        UserDefaults.standard.set((details["date-of-birth"] as? String), forKey: "dateofbirth")
                                        UserDefaults.standard.set((details["email-address"] as? String), forKey: "emailaddress")
                                        UserDefaults.standard.set((details["contact-number"] as? String), forKey: "contactnumber")
                                        UserDefaults.standard.set((details["payment-type"] as? String), forKey: "paymenttype")
                                        
                                    }
                                }
                            }
                    
                        }else{
                            print("Else Part")
                        }
                    }
                    
                }
                
            } catch {
                // handle error
            }
        }
    }
}

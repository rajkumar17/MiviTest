//
//  ViewController.swift
//  MiviTest
//
//  Created by Sogo Computers on 5/5/18.
//  Copyright © 2018 Sogo Computers. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {

    //MARK --- Variable or Constant
    
    @IBOutlet weak var txtfldUserId: UITextField!
    @IBOutlet weak var txtfldPassword: UITextField!
    
    //MARK ---
    override func viewDidLoad() {
        super.viewDidLoad()
        
        JSonParser.parseJSONFile()
        txtfldUserId.text = "0468874507"        
        // Do any additional setup after loading the view, typically from a nib.
    }
    //MARK: -- Function
    //MARK:  -- Alert View
    func showAlertView(message: String){
        let alert = UIAlertController(title: "Mivi Alert", message:message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: { () in
          
        })
    }

    @IBAction func clickSubmit(sender: UIButton){
        
        if (txtfldUserId.text == "") {
            print("Please enter the user details")
            let msg = "Please enter the user details"
            showAlertView(message: msg)
            
        }else if (txtfldUserId.text !=  UserDefaults.standard.string(forKey: "msn")){
            let msg = "Invalid User"
            showAlertView(message: msg)
        }
        else{
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ProductInfoControllerID") as! ProductInfoController
            self.present(nextViewController , animated:false, completion: nil)
        }
    }
    
    //MARK --- TextField Delegate Function
 

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let currentString: NSString = textField.text! as NSString
        let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= 30
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if txtfldUserId == textField{
            txtfldPassword.becomeFirstResponder()
        }else{
            txtfldPassword.resignFirstResponder()
        }
        return true
    }
    //MARK ---
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


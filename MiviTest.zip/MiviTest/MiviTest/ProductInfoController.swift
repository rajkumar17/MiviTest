
//
//  ProductInfoController.swift
//  MiviTest
//
//  Created by Sogo Computers on 5/5/18.
//  Copyright © 2018 Sogo Computers. All rights reserved.
//

import UIKit

class ProductInfoController: UIViewController, UITableViewDelegate,UITableViewDataSource {

    //MARK: -- Variable or constant
    @IBOutlet weak var tableViewList: UITableView!
    
    //MARK: --
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //MARK: -- TABLEVIEW DELEGATE FUNCTION
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }else if section == 1{
            return 1
        }else {
            return 1
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.section == 0 {
            return 80
        }else if indexPath.section == 1{
            return 44
        }else {
            return 140
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        //let indexPath = IndexPath(row: row, section: section)
        
        switch indexPath.section {
        case 0:
            if let cell = tableView.dequeueReusableCell(withIdentifier:"PlanCell", for: indexPath) as? PlanTableViewCell {
                
                cell.lblName.text = "Name: \(String(describing: UserDefaults.standard.string(forKey: "name") ?? ""))"
                cell.lblType.text = "Type: \(String(describing:  UserDefaults.standard.string(forKey: "paymenttype") ?? ""))"
                cell.lblBalance.text = "Balance: \(String(describing:  UserDefaults.standard.string(forKey: "included-data-balance") ?? "" ))"
                return cell
            }
        case 1:
            if let cell = tableView.dequeueReusableCell(withIdentifier:"ProductCell", for: indexPath) as? ProductTableViewCell {
                cell.lblPrice.text = "Price: \(String(describing: UserDefaults.standard.string(forKey: "price") ?? ""))"
                return cell
            }
        case 2:
            if let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath) as? UserDetTableViewCell {
            
                cell.lblTitle.text = "Title: \(String(describing: UserDefaults.standard.string(forKey: "title") ?? ""))"
                cell.lblName.text = "Name: \(String(describing: UserDefaults.standard.string(forKey: "name") ?? ""))"
                cell.lblDOB.text = "Dob: \(String(describing: UserDefaults.standard.string(forKey:"dateofbirth") ?? ""))"
                cell.lblEmailId.text = "Email Id: \(String(describing: UserDefaults.standard.string(forKey: "emailaddress") ?? ""))"
                cell.lblContactNo.text = "Contact No: \(String(describing: UserDefaults.standard.string(forKey: "contactnumber") ?? ""))"
                return cell
            }
        default:
            print("else part")
        }
        // return the default cell if none of above succeed
        return UITableViewCell()
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    //MARK: --
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
